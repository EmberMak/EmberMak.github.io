影ノ誓・弐  KAGE NO CHIKAI 2  v1.3  —  Windows 64-bit
© 2026 Kei Cheong Mai (EmberMak). All rights reserved. Free to play.

HOW TO RUN
1. Unzip this whole folder anywhere (e.g. Desktop). Do not run it from inside the zip.
2. Double-click KageNoChikai2.exe. Keep resources.neu next to the exe.
3. Windows SmartScreen may warn because the game is not code-signed:
   click "More info" > "Run anyway".
Needs Windows 10 or 11 (64-bit) with Microsoft Edge WebView2 (built in on
Windows 11 and up-to-date Windows 10; otherwise get it free from
https://developer.microsoft.com/microsoft-edge/webview2/).
Works fully offline. Progress saves automatically on this PC.

CONTROLS (press ? in-game for the controls sheet, F11 for fullscreen)
Exploring:  WASD / arrows walk/ride · Shift run · E/Enter talk/act
            H horse · Space jump · I/Tab inventory · M map · Esc pause/back
Duelling:   arrows/WASD = swipe: press the foe's arrow direction to parry
            (two keys for diagonals), then any direction to strike
            Space/J hold to block · Q step back · E jump (red unblockables)
            F Foxfire · R Kage-giri · Enter continue / take loot
Mouse works too.

Official site, web version and Android APK: https://embermak.github.io/kage-no-chikai-2/
See LICENSE.txt.
